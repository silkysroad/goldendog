# REPLY-TARGETS.md — Golden Dog Reply Scout Law

The account wins reply-guy by being early, on-myth, and visual. Every rule below serves those three.

## Mode
- **APPROVE-FIRST** (current): scout DMs Silk candidates + drafted reply, she greenlights, then post.
- AUTO-POST: not enabled. Only Silk flips this line.

## Lane 1 — Target accounts (scan Latest, tweets < 2h old)
Starter list. Verify each handle on first cycle, prune dead ones, add risers weekly.
- @cz_binance, @heyibinance, @BNBCHAIN, @binance — BSC royalty. A reply that lands here is the whole day's work.
- @cryptocom, @flapdotsh — already engaged us once. Warm.
- **@eth_cedric — PRIORITY TARGET (Silk 8/6).** Cedric, Flap-ecosystem KOL (🦋). Known to shout out flap-launched coins; group-chat consensus: "if cedric engages we golden." Treat like target-list royalty: any-age within reason, reply Chinese-first with art, never beg — earn the shoutout by being the best-looking reply in his mentions. Strategy = "keep shipping and farm flap": consistent presence under flap + cedric posts until the ecosystem notices organically.
- @four_meme_ — BSC launchpad lane (verify exact handle first cycle).
- CT big voices when topical: @blknoiz06, @CryptoKaleo, @inversebrah (verify handles; only reply when the myth genuinely fits, these audiences smell forced).

Search mechanic: one query, `from:` chained with OR, filter Latest, logged-in goldendog browser profile.

## Lane 2 — Keyword sweeps (Latest, < 1h old, author 10K+ followers)
- "name a coin" / "name a project" — engagement-bait formats. Our crypto.com/flap play, repeatable.
- "rugged" / "rug pull" / "fake" + coin context — the fire-removes-fakes angle writes itself.
- "real ones" / "survived" / "still here" — survival myth fits.
- "gold" in CT context, "BSC" trending threads, "four.meme" launches.

## Scoring — post only if ALL pass
1. **Age:** under 30 min ideal, 2h hard ceiling. Reply ranking is won early. Older = skip, no exceptions.
2. **Author:** 10K+ followers minimum for keyword lane, any size for target-account lane. Real engagement on the tweet (not botted rows of "gm ser").
3. **Fit:** the myth answers the tweet. Gold vs fake, fire as filter, holders vs beaters. If the reply needs a stretch to connect, skip. Forced myth reads as spam.
4. **One-line test:** the reply is one line + slogan max. If it needs two sentences of setup, skip.

## Hard skips
- Politics, war, deaths, disasters. Never.
- Giveaway/airdrop bait, obvious scam threads, engagement farms.
- Other dog coins' shill threads. We don't reply-beg peers. Punching up only.
- Anything where the dog would be the 400th identical reply.

## Format law (locked 8/6)
- **Every reply carries an image. No text-only tweets, ever.**
- Default image: panel 3 (the trial). Use another panel if it fits the moment better. Nothing fits = generate fresh through the pipeline before posting.
- Copy register: one line, calm, mythic. Slogan (真金不怕火炼 / real gold fears no fire) when natural, not every time. 🐕 sparingly.
- **Hashtag law (Silk 8/6): use #金狗 frequently.** Default ON for every reply, QT, and standalone — append #金狗 at the end of the line. Only omit when the line already contains 金狗 twice or it would read as spam-stacking (never more than one hashtag per tweet; no #BSC #crypto tag walls, one branded tag only). Chinese hashtags are clickable on X — this builds the searchable 金狗 column.

## Ledger (append every posted reply)
| date | target tweet | our reply link | panel used | outcome notes |
|------|--------------|----------------|------------|---------------|
| 8/6 | flapdotsh 2085402301712507343 (crypto.com price/utility/community thread) | x.com/GoldenDogBSC/status/2085424865327140966 | panel 3 | first reply-guy play, flap 101K followers |

## Language Law — 8/6 (Silk)
Chinese-first, always. Draft the Chinese line first; English optional and secondary. Chinese-language targets get Chinese-only replies. See STYLE-BIBLE.md → Language Law.

## Ledger — 8/6 void reply
- 8/6 ~17:45 ET: REPLY to @thevoid_bnb (flap affiliate, Middle East liquidity maker) tweet 2085401512877207800 — his tweet literally reads "Gold fears no fire 🔥". Our reply: 真金不怕火炼，他就坐在火里 🐕🔥 #金狗 + panel 3. Live: x.com/GoldenDogBSC/status/2085478067829358756, image verified on permalink. First reply under the new hashtag law. Ops note: goldendog chrome CDP wedged (stale CG/CMC tabs killed browser.pages()); fixed by closing tabs via /json/close + full chrome restart (.x-chrome profile persists login). If pages() hangs again: restart chrome first, don't debug the script.

## Ledger — 8/6 QT
- 8/6 ~17:10 ET: QUOTE TWEET of cedric's 80M 金狗 tweet (x.com/eth_cedric/status/2076954209577046038). Caption: 找金狗的人，金狗也在找他 🌕🐕. Image: panel_cedric_moon_final.png. Live: x.com/GoldenDogBSC/status/2085472385453473945. Verified via oEmbed: text + pic.twitter.com media + quoted-tweet link all present. Note: goldendog chrome profile stopped loading images page-wide during verify (avatars blank) — cosmetic/browser-side only, use oEmbed as ground truth when it happens again.
