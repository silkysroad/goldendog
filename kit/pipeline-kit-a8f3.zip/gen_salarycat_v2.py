#!/usr/bin/env python3
"""v2: salary cat + golden dog as clear FRIENDS — arm around shoulder, both happy, toasting tea."""
import base64, json, os, sys, subprocess
from gen_panel import STYLE

KEY = None
for line in open(os.path.expanduser("~/.openclaw/.env")):
    if line.startswith("OPENAI_API_KEY="):
        KEY = line.strip().split("=", 1)[1]
assert KEY

D = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(D, "panel_salarycat_v2.png")

SCENE = (
    "Evening village scene under warm red paper lanterns. Two best friends sitting "
    "SIDE BY SIDE on the same wooden bench, shoulder to shoulder, at a low tea table: "
    "(1) the golden dog from the first reference image, redrawn in flat woodblock style, "
    "solid imperial-gold fill with ink outline, with one arm/foreleg wrapped warmly AROUND "
    "the cat's shoulders in a clear friendly hug, big happy closed-eye smile; "
    "(2) his best friend, a soft round chubby little cat drawn in the same flat woodblock "
    "linework: cream-WHITE body, LIGHT TAN-BROWN patches on the top of its head and its "
    "fluffy triangular ears, simple dark-brown outline instead of black. "
    "CRITICAL COLOR EXCEPTION — the cat keeps these soft pastel colors: cream-white body, "
    "light tan-brown head patches and ears, dark-brown outline, tiny blue eyes. Do NOT "
    "recolor it red, gold, or vermillion; its softness against the warm bold palette is "
    "the whole point. "
    "The cat's face is fully uncovered, paws DOWN away from the face, one paw holding a "
    "tea cup. Face clearly visible and HAPPY: two short vertical blue dash eyes curved "
    "with joy, a tiny w-shaped smiling open cat mouth, rosy pink cheek dots. Zero tears. "
    "BOTH characters face the viewer in front three-quarter view like a friendship "
    "portrait, the cat's head leaning affectionately against the dog's shoulder. The cat raises a small tea cup and the "
    "dog raises his own so the two cups CLINK in a toast in front of them, steam rising. "
    "On the table: a small stack of gold bricks and a red salary envelope pushed together "
    "into one shared pile. Body language reads instantly as two best friends celebrating "
    "together after a long work day. Composition: both characters large, centered, "
    "cheek to cheek, clearly readable; lanterns above, village rooftops and a full moon "
    "behind."
)

STYLE2 = STYLE.replace(
    "small accents of deep green.",
    "small accents of deep green, PLUS cream-white, light tan-brown and tiny blue eye "
    "accents which are reserved EXCLUSIVELY for the guest cat character — that cat is "
    "painted ONLY in its cream/tan/brown/blue colors, never red, never gold.",
)
prompt = STYLE2 + "\n\n" + SCENE
r = subprocess.run([
    "curl", "-s", "https://api.openai.com/v1/images/edits",
    "-H", f"Authorization: Bearer {KEY}",
    "-F", "model=gpt-image-1",
    "-F", f"image[]=@{os.path.join(D, '_emblem_ref.png')}",
    "-F", f"prompt={prompt}",
    "-F", "size=1024x1024",
    "-F", "quality=high",
    "-F", "input_fidelity=high",
], capture_output=True, text=True, timeout=600)
try:
    resp = json.loads(r.stdout)
except Exception:
    print("BAD RESPONSE:", r.stdout[:1000], r.stderr[:500]); sys.exit(2)
if "data" in resp and resp["data"] and "b64_json" in resp["data"][0]:
    open(OUT, "wb").write(base64.b64decode(resp["data"][0]["b64_json"]))
    print("saved", OUT)
else:
    print("ERROR:", json.dumps(resp)[:1500]); sys.exit(1)
