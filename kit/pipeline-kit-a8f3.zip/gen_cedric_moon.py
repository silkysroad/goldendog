#!/usr/bin/env python3
"""One-off: Cedric's ice character + golden dog hanging on the moon. Two refs."""
import base64, json, os, sys, subprocess
from gen_panel import STYLE

KEY = None
for line in open(os.path.expanduser("~/.openclaw/.env")):
    if line.startswith("OPENAI_API_KEY="):
        KEY = line.strip().split("=", 1)[1]
assert KEY

D = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(D, "panel_cedric_moon_v1.png")

SCENE = (
    "Night scene: an enormous full moon fills most of the frame, glowing pale gold "
    "against a deep ink-black night sky with a few flat woodblock clouds. SITTING TOGETHER "
    "ON TOP OF THE MOON, side by side like two old friends hanging out, are two characters: "
    "(1) the golden dog from the first reference image, redrawn in flat woodblock style, "
    "solid imperial-gold fill, relaxed and content; "
    "(2) the grumpy ice creature from the second reference image: a small figure whose head "
    "is a jagged iceberg crystal, with a round pale face, heavy-lidded grumpy frowning eyes "
    "and a blocky crystalline ice body. Redraw this ice creature in the same flat woodblock "
    "linework BUT — CRITICAL COLOR EXCEPTION — the ice creature MUST keep its original "
    "LIGHT ICE-BLUE crystal color with pale cream face, exactly like the reference. "
    "It is made of blue ice. Do NOT recolor it red, gold, or vermillion under any "
    "circumstances; its cool blue against the warm palette is the whole point. "
    "Same grumpy expression. The ice creature sits beside the dog, "
    "both gazing down at the tiny sleeping village far below at the bottom of the frame. "
    "Warm companionship, two legends sharing the night watch. The dog's curled tail rests "
    "near the ice creature. Composition: moon dominates, characters clearly readable on its "
    "upper curve, tiny village rooftops below."
)

STYLE2 = STYLE.replace(
    "small accents of deep green.",
    "small accents of deep green, PLUS light ice-blue and pale frost-white which are "
    "reserved EXCLUSIVELY for the ice creature guest character (the second reference "
    "image) — that character is painted ONLY in ice-blue and frost tones, never red, "
    "never gold.",
)
prompt = STYLE2 + "\n\n" + SCENE
r = subprocess.run([
    "curl", "-s", "https://api.openai.com/v1/images/edits",
    "-H", f"Authorization: Bearer {KEY}",
    "-F", "model=gpt-image-1",
    "-F", f"image[]=@{os.path.join(D, '_emblem_ref.png')}",
    "-F", f"image[]=@{os.path.join(D, '_cedric_ref.png')}",
    "-F", f"prompt={prompt}",
    "-F", "size=1024x1024",
    "-F", "quality=high",
    "-F", "input_fidelity=high",
], capture_output=True, text=True, timeout=600)
try:
    resp = json.loads(r.stdout)
except Exception:
    print("BAD RESPONSE:", r.stdout[:1000], r.stderr[:500]); sys.exit(2)
if "data" in resp and resp["data"] and "b64_json" in resp["data"][0]:
    open(OUT, "wb").write(base64.b64decode(resp["data"][0]["b64_json"]))
    print("saved", OUT)
else:
    print("ERROR:", json.dumps(resp)[:1500]); sys.exit(1)
