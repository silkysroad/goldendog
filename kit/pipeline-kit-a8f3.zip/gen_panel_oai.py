#!/usr/bin/env python3
"""Golden Dog story panels via OpenAI gpt-image-1 (images/edits w/ emblem ref).
Usage: python3 gen_panel_oai.py <panel_key> <out.png>
"""
import base64, json, os, sys, subprocess
from gen_panel import PANELS, STYLE, EMBLEM

KEY = None
for line in open(os.path.expanduser("~/.openclaw/.env")):
    if line.startswith("OPENAI_API_KEY="):
        KEY = line.strip().split("=", 1)[1]
assert KEY

MODEL = os.environ.get("GD_OAI_MODEL", "gpt-image-1")

def main():
    key_name, out = sys.argv[1], sys.argv[2]
    prompt = STYLE + "\n\n" + PANELS[key_name]
    r = subprocess.run([
        "curl", "-s", "https://api.openai.com/v1/images/edits",
        "-H", f"Authorization: Bearer {KEY}",
        "-F", f"model={MODEL}",
        "-F", f"image[]=@{os.path.join(os.path.dirname(os.path.abspath(__file__)), '_emblem_ref.png')}",
        "-F", f"prompt={prompt}",
        "-F", "size=1024x1024",
        "-F", "quality=high",
        "-F", "input_fidelity=high",
    ], capture_output=True, text=True, timeout=600)
    try:
        resp = json.loads(r.stdout)
    except Exception:
        print("BAD RESPONSE:", r.stdout[:1000], r.stderr[:500]); sys.exit(2)
    if "data" in resp and resp["data"] and "b64_json" in resp["data"][0]:
        open(out, "wb").write(base64.b64decode(resp["data"][0]["b64_json"]))
        print("saved", out)
    else:
        print("ERROR:", json.dumps(resp)[:1500]); sys.exit(1)

if __name__ == "__main__":
    main()
