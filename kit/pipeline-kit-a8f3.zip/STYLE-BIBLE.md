# Golden Dog — House Style Bible
One page. Every image the account posts follows this. No exceptions.

## The Style
Traditional Chinese **nianhua New Year woodblock print**. Flat, hand-carved, ornamental. It is a rule set, not a vibe.

## The Five Laws
1. **Linework:** flat black ink woodblock lines. No gradients, no 3D shading, no drop shadows, no photorealism.
2. **Palette (strict):**
   - Paper cream ground: `#F5EAD0` (aged rice paper, subtle grain)
   - Vermillion red: `#C42F1F`
   - Imperial gold: `#E8B62C`
   - Ink black: `#1A1512`
   - Deep green accent (sparing): `#2E5E3F`
3. **The dog:** ALWAYS redrawn in woodblock style. Same silhouette every time: sturdy guardian dog, curled tail, proud chest. Solid gold fill, bold ink outline, simple carved detail lines. NEVER paste the shiny 3D emblem into a scene. The emblem is the logo; the woodblock dog is the actor.
4. **Frame:** thin decorative vermillion woodblock border on every image.
5. **The seal:** 金狗 red seal stamped bottom-right on every image. Applied in post via `stamp_seal.py` — pixel-identical across all images, never generated.

## Text Rule
NO text baked into the art. No letters, no characters, no signage. Copy lives in the tweet. (Only exception: the post-applied seal.)

## Pipeline (scripted — do not freehand)
Directory: `websites/goldendog/story/`
1. Generate: `python3 gen_panel_oai.py <panel_key> <out_v1.png>` — gpt-image-1, emblem as locked character ref, STYLE block auto-injected. Gemini key on this machine is free-tier, dead for images; OpenAI key only.
2. Stamp: `python3 stamp_seal.py <out_v1.png> <out_final.png>`
3. New scenes: add a prompt to `PANELS` in `gen_panel.py` (scene description only — never restate style, the STYLE block handles it).

## Extending Beyond the Story
Any new format (reaction image, milestone post, gm image, chart background) = dog + one prop + one line of tweet copy, same five laws. If an image wouldn't sit cleanly in a grid with panels 1–5, it doesn't post.

## Posting Rule — LOCKED 8/6 (Silk)
**Every post AND reply from @GoldenDogBSC includes an image. No text-only tweets, ever.** Replies default to panel 3 (the trial) unless another panel fits the context better. If no existing panel fits, generate a new one through the pipeline before posting.

## Canon
- Slogan / bio: **"real gold fears no fire"** (真金不怕火炼)
- Story arc: 1 claim → 2 fire → 3 trial → 4 emergence → 5 settlement → 6 seal
- Hero image: panel 3 (the trial) — conflict in-frame, works with zero caption
- Settlement copy: 打狗人空手而归. 持狗者坐等分金.

## Language Law — LOCKED 8/6 (Silk): CHINESE-FIRST, ALWAYS
The account is Chinese-coded. Chinese is the primary language, English is the annotation — never the reverse.
- **Tweets/replies: lead with the Chinese line.** English (if included at all) comes second, shorter, or not at all. Under Chinese-language accounts (BNB ZH, CN KOLs): Chinese only.
- **Bio/profile: Chinese first.** 真金不怕火炼 before "real gold fears no fire."
- **Website: jingou.gold serves the Chinese edition at `/`.** English lives at `/en.html`, reachable via the ENGLISH button top-right of the masthead. Never flip this back.
- Idioms are the voice: 真金不怕火炼 · 金狗深夜出没 · 打狗人空手而归，持狗者坐等分金. Use real CT-Chinese degen phrasing, never machine-translated English thoughts.

## Hashtag Law — 8/6 (Silk)
Every tweet, reply, and QT carries **#金狗** at the end of the line by default. Exactly one hashtag per tweet — never tag walls, never #BSC #crypto stacking. Omit only if the line already reads 金狗 twice. Purpose: build the searchable #金狗 column on X so discovery compounds.
