#!/usr/bin/env python3
"""Golden Dog story panels — nianhua woodblock house style, Gemini image gen.
Usage: python3 gen_panel.py <panel_key> <out.png>
Reads GEMINI_API_KEY from ~/.openclaw/.env. Uses golden_dog_emblem.png as character ref.
"""
import base64, json, os, sys, urllib.request, io

ENV = os.path.expanduser("~/.openclaw/.env")
KEY = None
for line in open(ENV):
    if line.startswith("GEMINI_API_KEY="):
        KEY = line.strip().split("=", 1)[1]
assert KEY, "no gemini key"

MODEL = os.environ.get("GD_MODEL", "gemini-3-pro-image")
HERE = os.path.dirname(os.path.abspath(__file__))
EMBLEM = os.path.join(HERE, "..", "golden_dog_emblem.png")

STYLE = (
    "House style, follow exactly: traditional Chinese nianhua New Year woodblock print. "
    "Flat hand-carved woodblock linework in black ink, flat color fills only, no gradients, no 3D shading, no drop shadows, no photorealism. "
    "Palette strictly limited to: aged warm rice-paper cream background with subtle paper grain, vermillion red, imperial gold-yellow, black ink, small accents of deep green. "
    "A thin decorative vermillion woodblock border frames the whole image like a New Year print. "
    "The golden dog character from the reference image must be REDRAWN in this flat woodblock style: exact same silhouette and pose language (sturdy guardian dog, curled tail, proud chest), solid imperial-gold fill, bold black ink outline, simple carved detail lines. Do not paste or render the reference emblem's shiny 3D style. "
    "ABSOLUTELY NO text, no letters, no Chinese characters, no writing, no signage, no seals anywhere in the image. Purely visual."
)

PANELS = {
    "p1": (
        "Scene: THE CLAIM. A festive village street crowded with many other dogs of ordinary colors, each wearing cheap flaking gold paint, "
        "posing boastfully on pedestals and market stalls, flecks of gold paint chipping off some of them. "
        "In the foreground, slightly apart from the crowd, stands the one true golden dog from the reference, calm and unbothered, its gold solid and clean. "
        "Composition: busy symmetrical village scene like a classic nianhua market print, lanterns and rooftops, the true golden dog set apart and reading instantly."
    ),
    "p3": (
        "Scene: THE TRIAL. The golden dog from the reference sits perfectly calm and dignified in the center of a great furnace, "
        "surrounded on all sides by huge stylized woodblock flames in vermillion red and gold, curling like classical Chinese cloud-and-flame motifs. "
        "The dog is untouched and serene, eyes closed or steady, seated like a temple guardian statue. "
        "Composition: centered, symmetrical, iconic. The flames fill the frame around the dog like a mandorla of fire."
    ),
    "p2": (
        "Scene: THE FIRE. Night scene. A crowd of jeering dogs and villagers hurls the golden dog toward the open mouth of a huge traditional brick kiln furnace glowing vermillion and gold. "
        "The golden dog mid-air above the furnace mouth, calm even while falling, body relaxed and dignified. "
        "Composition: diagonal energy from crowd at left to furnace at right, woodblock smoke curls, dramatic but flat and ornamental."
    ),
    "p4": (
        "Scene: THE EMERGENCE. Morning after the fire. The golden dog walks out of the cooled furnace mouth, radiant solid gold, head high, mid-stride. "
        "Around the furnace lie gray heaps of ash in the shapes of collapsed dogs, the flaked remains of the fake painted dogs. "
        "Composition: the golden dog center-right walking toward the viewer, ash heaps low and muted, rising sun as a flat vermillion disc."
    ),
    "night": (
        "Scene: THE NIGHT HUNT. Deep night over a sleeping village: rooftops dark, windows shut, lanterns extinguished, sleeping figures visible dozing inside doorways. "
        "The sky is deep black ink wash with a large flat pale-cream full moon disc and a few carved star marks. "
        "On the highest rooftop ridge stands the golden dog from the reference, wide awake and alert, the only bright gold thing in the scene, radiant against the dark, eyes open, ears up, mid-prowl stance, moonlight rimming its outline. "
        "Composition: the dog silhouetted proudly against the huge moon, sleeping village low and dark below, a sense that the dog owns the night while everyone else sleeps."
    ),
    "p5": (
        "Scene: THE SETTLEMENT. A long banquet table inside a courtyard hall, dogs seated calmly around it like honored elders. "
        "The golden dog from the reference runs joyfully across the courtyard toward an enormous gleaming stack of gold bricks piled like a pyramid. "
        "Through the gate in the background, defeated stick-carrying figures walk away empty-handed into the distance. "
        "Composition: classical courtyard perspective of a nianhua print, gold brick pile as the radiant focal point."
    ),
}

def main():
    key_name, out = sys.argv[1], sys.argv[2]
    prompt = STYLE + "\n\n" + PANELS[key_name]
    ref = base64.b64encode(open(EMBLEM, "rb").read()).decode()
    body = {
        "contents": [{
            "parts": [
                {"inline_data": {"mime_type": "image/png", "data": ref}},
                {"text": prompt},
            ]
        }],
        "generationConfig": {
            "responseModalities": ["IMAGE"],
            "imageConfig": {"aspectRatio": "1:1"},
        },
    }
    req = urllib.request.Request(
        f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={KEY}",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        resp = json.load(urllib.request.urlopen(req, timeout=300))
    except urllib.error.HTTPError as e:
        print("HTTP", e.code, e.read().decode()[:1500])
        sys.exit(2)
    for part in resp["candidates"][0]["content"]["parts"]:
        if "inlineData" in part:
            open(out, "wb").write(base64.b64decode(part["inlineData"]["data"]))
            print("saved", out)
            return
    print("NO IMAGE:", json.dumps(resp)[:2000])
    sys.exit(1)

if __name__ == "__main__":
    main()
