#!/usr/bin/env python3
"""Stamp the 金狗 red seal bottom-right on a story panel. Usage: stamp_seal.py in.png out.png"""
import sys, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

VERMILLION = (196, 47, 31, 235)
FONT = "/System/Library/Fonts/Supplemental/Songti.ttc"

def make_seal(size=118):
    s = size * 4  # supersample
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # rough-edged square: jittered polygon
    rng = random.Random(88)
    pts = []
    steps = 14
    m = s * 0.06
    corners = [(m, m), (s - m, m), (s - m, s - m), (m, s - m)]
    for i in range(4):
        x0, y0 = corners[i]
        x1, y1 = corners[(i + 1) % 4]
        for t in range(steps):
            f = t / steps
            x = x0 + (x1 - x0) * f + rng.uniform(-s * 0.012, s * 0.012)
            y = y0 + (y1 - y0) * f + rng.uniform(-s * 0.012, s * 0.012)
            pts.append((x, y))
    d.polygon(pts, fill=VERMILLION)
    # characters 金 / 狗 stacked, carved out in paper-white
    font = ImageFont.truetype(FONT, int(s * 0.40), index=0)
    for ch, cy in (("金", 0.28), ("狗", 0.72)):
        bb = d.textbbox((0, 0), ch, font=font)
        w, h = bb[2] - bb[0], bb[3] - bb[1]
        d.text((s / 2 - w / 2 - bb[0], s * cy - h / 2 - bb[1]), ch, font=font, fill=(245, 234, 208, 255))
    img = img.filter(ImageFilter.GaussianBlur(1.2))
    return img.resize((size, size), Image.LANCZOS)

def main():
    src, out = sys.argv[1], sys.argv[2]
    panel = Image.open(src).convert("RGBA")
    W, H = panel.size
    seal = make_seal(int(W * 0.115))
    pad = int(W * 0.075)
    panel.alpha_composite(seal, (W - seal.width - pad, H - seal.height - pad))
    panel.convert("RGB").save(out, quality=95)
    print("stamped", out)

if __name__ == "__main__":
    main()
